import { config } from 'dotenv';
config();

import '@/ai/flows/ai-chat-concierge.ts';